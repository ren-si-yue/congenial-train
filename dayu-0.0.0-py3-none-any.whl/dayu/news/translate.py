import os
import requests

from .good import pacing


# DeepL API 是我们使用的翻译服务
def translate_to_english(text):
    url = "https://api-free.deepl.com/v2/translate"
    params = {
        "auth_key": os.getenv("DEEPL_API_KEY"),
        "text": text,
        "target_lang": "EN"
    }
    response = requests.post(url, data=params)
    if response.status_code == 200:
        return response.json()["translations"][0]["text"]
    else:
        print(f"Error: {response.status_code}")
        return None


def gnews_ge_to_en(gnews_items):
    translated_news = []

    # 假设 news 是包含新闻内容的列表
    for item in gnews_items:
        title = item.get('title')
        content = item.get('description')

        # 翻译标题和内容
        if title:
            translated_title = translate_to_english(title)
            if translated_title:
                item['title'] = translated_title

        if content:
            translated_content = translate_to_english(content)
            if translated_content:
                item['description'] = translated_content

        translated_news.append(item)
        pacing()
    return translated_news
