# meta data used for a crawled Record

TYPES = ['sys conf', 'arxiv', 'news']
VENUES = {
    'sys conf': ['osdi 2023', 'sosp 2023'],
    'arxiv': ['ML'],
    'news': ['google news', 'hacker news', 'weibo top', 'rss']
}
ELEMENTS = [
    'type', 'venue', 'date', 'title', 'keyword', 'summarize', 'author',
    'affilication', 'url'
]

from datetime import date, datetime


class Record:

    def __init__(self):
        self.type = None
        self.venue = None
        self.date = None
        self.title = None
        self.keyword = None
        self.summarize = None
        self.author = None
        self.affilication = None
        self.url = None

    def validate(self):
        assert self.type in TYPES
        assert self.venue in VENUES[self.type]
        self.date = self.clean_element(self.date, 'date')
        self.title = self.clean_element(self.title, 'title')
        self.keyword = self.clean_element(self.keyword, 'keyword')
        self.author = self.clean_element(self.author, 'author')
        self.affilication = self.clean_element(self.affilication,
                                               'affilication')
        self.url = self.clean_element(self.url, 'url')

    def clean_element(self, text: str, tag: str):
        assert tag in ELEMENTS
        if text is None or text.strip() == '':
            return "N/A"

        def clean(text_):
            text_ = text_.strip()
            text_ = " ".join(text_.split())
            return text_

        text_ = clean(text)
        if tag == 'date':
            try:
                _ = datetime.fromisoformat(text_)
            except ValueError:
                text_ = self.today()
        return text_

    def today(slef):
        return datetime.now().strftime(("%Y-%m-%d 00:00"))

    def now(slef):
        return datetime.now().strftime(("%Y-%m-%d %H:00"))

    def __str__(self) -> str:
        return f"{self.type}|{self.venue}|{self.date}|{self.title}|{self.keyword}|{self.summarize}|{self.author}|{self.affilication}|{self.url}"
