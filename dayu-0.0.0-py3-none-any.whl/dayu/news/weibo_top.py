# -*- coding: utf-8 -*-
# @Author    : Eurkon
# @Date      : 2021/6/5 10:16

import json, re
import requests
from lxml import etree

from baikal.record import Record

# https://github.com/v5tech/weibo-trending-hot-search/blob/master/main.py


# 获取内容
def fetch_weibo(url):
    try:
        headers = {
            "Cookie":
                "SUB=_2AkMWIuNSf8NxqwJRmP8dy2rhaoV2ygrEieKgfhKJJRMxHRl-yT9jqk86tRB6PaLNvQZR6zYUcYVT1zSjoSreQHidcUq7",
            "User-Agent":
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36 Edg/90.0.818.41"
        }
        resp = requests.get(url, headers=headers)
        if resp.status_code == 200:
            print("weibo_top: 抓取完毕...")
            return resp.content.decode("utf-8")
        return None
    except RequestException:
        return None


# xpath解析微博热搜数据
def get_weibo_top_data():
    baseurl = 'https://s.weibo.com'
    url = f'{baseurl}/top/summary?cate=realtimehot'
    content = fetch_weibo(url)

    html = etree.HTML(content)
    xpath = '//*[@id="pl_top_realtimehot"]/table/tbody/tr[position()>1]/td[@class="td-02"]/a[not(contains(@href, "javascript:void(0);"))]'
    titles = html.xpath(f'{xpath}/text()')
    hrefs = html.xpath(f'{xpath}/@href')
    hots = html.xpath(f'{xpath}/../span/text()')
    titles = [title.strip() for title in titles]
    hrefs = [f"{baseurl}{href.strip()}" for href in hrefs]
    hots = [hot.strip() for hot in hots]
    hot_news = []
    for i, title in enumerate(titles):
        if i > 9:
            break
        hot_news.append({
            'title': title,
            'url': f"{hrefs[i]}",
            'hot': int(re.findall(r'\d+', hots[i])[0])
        })

    print("weibo_top: 解析完毕...")

    return hot_news


def handle_weibo(records: list):
    for d in get_weibo_top_data():
        r = Record()
        r.type = 'news'
        r.venue = 'weibo top'
        r.date = r.now()
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = 'N/A'
        r.author = 'N/A'
        r.affilication = 'N/A'
        r.url = d['url']
        r.validate()
        records.append(r)
