from gnews import GNews
from datetime import date

# from .translate import gnews_ge_to_en

from baikal.record import Record


def get_google_news_data():
    news = []
    google_news = GNews()
    google_news.period = '1d'  # News from last 7 days
    google_news.max_results = 5  # number of responses across a keyword
    google_news.country = 'United States'  # News from a specific country
    google_news.language = 'english'  # News in a specific language
    google_news.exclude_websites = [
        'yahoo.com', 'cnn.com'
    ]  # Exclude news from specific website i.e Yahoo.com and CNN.com
    google_news.start_date = None  # Search from 1st Jan 2020
    google_news.end_date = None  # (date.today().year, date.today().month, date.today().day) # Search until 1st March 2020

    n = google_news.get_news_by_topic('WORLD')
    news.extend(n)
    n = google_news.get_news_by_topic('BUSINESS')
    news.extend(n)
    n = google_news.get_news_by_topic('TECHNOLOGY')
    news.extend(n)

    google_news.country = 'Germany'  # News from a specific country
    google_news.language = 'german'  # News in a specific language
    google_news.max_results = 3  # number of responses across a keyword

    n = google_news.get_news_by_topic('WORLD')
    #news.extend(gnews_ge_to_en(n))
    news.extend(n)
    n = google_news.get_news_by_topic('BUSINESS')
    news.extend(n)
    n = google_news.get_news_by_topic('TECHNOLOGY')
    news.extend(n)

    return news


def get_google_news_sites_data():

    news = []
    google_news = GNews()
    google_news.period = '1d'  # News from last 7 days
    google_news.max_results = 10  # number of responses across a keyword
    google_news.exclude_websites = [
        'yahoo.com', 'cnn.com'
    ]  # Exclude news from specific website i.e Yahoo.com and CNN.com
    google_news.start_date = None  # Search from 1st Jan 2020
    google_news.end_date = None  # (date.today().year, date.today().month, date.today().day) # Search until 1st March 2020
    sites = [
        'newyorker.com', 'euronews.com', 'theguardian.com/europe',
        'www.wired.com', 'www.thepaper.cn', 'spiegel.de', 'thetimes.co.uk',
        'economist.com', 'www.janes.com/osint-insights/defence-news'
    ]
    for site in sites:
        n = google_news.get_news_by_site(site)
        news.extend(n)

    return news


def handle_google_news(records: list):
    for d in get_google_news_data():
        r = Record()
        r.type = 'news'
        r.venue = 'google news'
        r.date = d['published date']
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = d['description']
        r.author = 'N/A'
        r.affilication = d['publisher']['title']
        r.url = d['url']
        r.validate()
        records.append(r)


def handle_google_news_sites(records: list):
    for d in get_google_news_sites_data():
        r = Record()
        r.type = 'news'
        r.venue = 'google news'
        r.date = d['published date']
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = d['description']
        r.author = 'N/A'
        r.affilication = d['publisher']['title']
        r.url = d['url']
        r.validate()
        records.append(r)
