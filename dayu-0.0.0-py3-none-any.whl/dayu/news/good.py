import numpy as np
import time


def pacing():
    ms = np.random.poisson(lam=100.0)
    time.sleep(1.0 / 1000 * ms)
