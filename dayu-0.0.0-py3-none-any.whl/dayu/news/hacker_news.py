import requests, json

from baikal.record import Record

TOP_N = 7
BEST_N = 3


def get_hacker_news_data():
    news = []

    response = requests.get(
        'https://hacker-news.firebaseio.com/v0/topstories.json?print=pretty')
    if response.status_code == 200:
        top = json.loads(response.content)
        for a in top[:TOP_N]:
            url = f"https://hacker-news.firebaseio.com/v0/item/{a}.json?print=pretty"
            response = requests.get(url)
            if response.status_code == 200:
                d = json.loads(response.content)
                d['url'] = url if 'url' not in d else d['url']
                news.append(d)

    response = requests.get(
        'https://hacker-news.firebaseio.com/v0/beststories.json?print=pretty')
    if response.status_code == 200:
        top = json.loads(response.content)
        for a in top[:BEST_N]:
            url = f"https://hacker-news.firebaseio.com/v0/item/{a}.json?print=pretty"
            response = requests.get(url)
            if response.status_code == 200:
                d = json.loads(response.content)
                d['url'] = url if 'url' not in d else d['url']
                news.append(d)

    return news


def handle_hacker_news(records: list):
    for d in get_hacker_news_data():
        r = Record()
        r.type = 'news'
        r.venue = 'hacker news'
        r.date = str(d['time'])
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = d['text'] if 'text' in d else 'N/A'
        r.author = d['by']
        r.affilication = 'Hacker News'
        r.url = d['url']
        r.validate()
        records.append(r)
