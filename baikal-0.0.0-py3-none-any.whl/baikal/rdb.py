import os
import duckdb as db
import shutil

from .config import DATA_ROOT, BACKUP_ROOT


class RDB:

    def __init__(self, db_name):
        self.db_name = db_name
        self.con = None

        self.db_path = os.path.join(DATA_ROOT, f"{db_name}.db")
        if not os.path.exists(self.db_path):
            self._create()

    def _create(self):
        pass

    def open(self):
        self.con = db.connect(self.db_path)

    def close(self):
        self.con.close()
        backup = os.path.join(BACKUP_ROOT, f"{self.db_name}.db")
        shutil.copy2(self.db_path, backup)

    def exe(self, sql):
        return self.con.sql(sql)

    def verbose(self):
        print(f"{'-'*10}RDB{'-'*10}")
        print(f"db_name: {self.db_name}")
        print(f"db_path: {self.db_path}")
        tables = self.con.execute("PRAGMA show_tables").fetchall()
        print(f"Tables : {[ t[0] for t in tables ]}")
        print(f"{'-'*10}---{'-'*10}")
