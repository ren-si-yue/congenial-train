import feedparser

from baikal.record import Record

RSS_LIST = [
    "https://www.theverge.com/rss/index.xml", "https://techcrunch.com/feed/"
]


def get_rss_data():
    data = []
    for url in RSS_LIST:
        feed = feedparser.parse(url)
        for entry in feed.entries[:10]:  # Limit to the first 10 entries
            d = {}
            d['title'] = str(entry.title)
            d['url'] = entry.link
            d['date'] = entry.published
            d['summary'] = ""

            if entry.title is None or entry.title.strip() == "":
                d = {}
            else:
                data.append(d)
    return data


def handle_rss(records: list):
    for d in get_rss_data():
        r = Record()
        r.type = 'news'
        r.venue = 'rss'
        r.date = d['date']
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = d['summary']
        r.author = 'N/A'
        r.affilication = 'N/A'
        r.url = d['url']
        r.validate()
        records.append(r)
