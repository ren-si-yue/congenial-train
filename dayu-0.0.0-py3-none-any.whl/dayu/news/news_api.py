from newsapi import NewsApiClient

from baikal.record import Record

## /v2/top-headlines/sources
#sources = newsapi.get_sources()
#if sources['status'] == 'ok':
#    for i in sources['sources']:
#        print(i['id'], i['name'], i['url'])


# is NewsApiClient a wrapper of https://newsapi.org/?
def get_newsapi_data():

    # doc
    # https://newsapi-python.readthedocs.io/en/latest/index.html
    newsapi = NewsApiClient(api_key='3d7ec061fd0f419f896e01f31d5da9f0')

    # /v2/top-headlines
    ret = newsapi.get_top_headlines(
        #q='china',
        sources='bbc-news,bloomberg,die-zeit,reuters,wired,xinhua-net,time',
        category=None,
        language='en',
        country=None)

    if ret['status'] == 'ok':
        return ret['articles']


def handle_news_api(records: list):
    for d in get_newsapi_data():
        r = Record()
        r.type = 'news'
        r.venue = 'google news'
        r.date = str(d['publishedAt'])
        r.title = d['title']
        r.keyword = 'N/A'
        r.summarize = d['description'] if 'description' in d else 'N/A'
        r.author = d['author']
        r.affilication = d['source']['name']
        r.url = d['url']
        r.validate()
        records.append(r)
