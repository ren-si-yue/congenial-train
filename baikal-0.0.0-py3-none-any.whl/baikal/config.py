DATA_ROOT = '/tmp/news'
BACKUP_ROOT = '/tmp/news_backup'
