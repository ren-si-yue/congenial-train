from ..rdb import RDB
from ..record import Record

import hashlib


class SqlLeisureNews(RDB):

    def __init__(self, db_name):
        super().__init__(db_name)

    def _create(self):
        self.open()
        self.exe(
            'CREATE TABLE feeds (id CHAR(32) PRIMARY KEY, type VARCHAR(255), venue VARCHAR(255), date DATE, title VARCHAR(255), keyword VARCHAR(255), overview VARCHAR(512), author VARCHAR(255), affiliation VARCHAR(255), url VARCHAR(255));'
        )

    def add_record(self, r: Record):
        try:
            md5hash = hashlib.md5(r.title.encode()).hexdigest()
            self.exe(
                f"INSERT INTO feeds (id, type, venue, date, title, keyword, overview, author, affiliation, url) VALUES (\'{md5hash}\', \'{r.type}\', \'{r.venue}\', \'{r.date}\', \'{r.title}\', \'{r.keyword}\', \'{r.summarize}\', \'{r.author}\', \'{r.affilication}\', \'{r.url}\');"
            )
        except Exception:
            pass

    def get_data_frame(self):
        arrow_table = self.exe('SELECT * FROM feeds WHERE date = CURRENT_DATE'
                              ).fetch_arrow_table()
        df = arrow_table.to_pandas()
        return df
